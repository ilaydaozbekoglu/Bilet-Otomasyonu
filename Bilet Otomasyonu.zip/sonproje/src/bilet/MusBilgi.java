package bilet;

public class MusBilgi {
    public String isim;
    public String soyisim;
    public String numara;

    MusBilgi(String isim,String soyisim, String numara){
        this.isim = isim;
        this.soyisim = soyisim;
        this.numara = numara;
    }
}
