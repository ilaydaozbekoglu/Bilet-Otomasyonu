package bilet;

public interface islemler {
    void biletAl(); //Ortak kullanılan bilet alma fonksiyonu.
    void kisiİnfo(); // Ortak olarak kullanılan müşteri bilgisi alma fonksiyonu.
}
