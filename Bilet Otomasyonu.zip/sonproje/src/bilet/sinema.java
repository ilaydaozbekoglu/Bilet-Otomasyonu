package bilet;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class sinema implements islemler {


    Scanner scan = new Scanner(System.in);

    public void biletAl(
            ArrayList<String> arrayList10,
            ArrayList<String> arrayList12,
            ArrayList<String> arrayList14,
            ArrayList<String> arrayList16,
            ArrayList<String> arrayList18) {
        biletSat(arrayList10, arrayList12, arrayList14, arrayList16, arrayList18);

    }

    @Override
    public void biletAl() {

    }

    @Override
    public void kisiİnfo() {

    }


    public void biletSat(
            ArrayList<String> arrayList10,
            ArrayList<String> arrayList12,
            ArrayList<String> arrayList14,
            ArrayList<String> arrayList16,
            ArrayList<String> arrayList18) {

        System.out.println("kişi sayısı:");
        int kisi = scan.nextInt();
        if (kisi <= 0) {
            System.out.println("geçersiz bir kişi sayısı girildi. Lütfen yeniden deneyiniz.");
            return;
        }
        System.out.println("indirimli bilet sayısı:");
        int indBilet = scan.nextInt();
        if (indBilet < 0) {
            System.out.println("hatalı veri girişi.");
            return;
        }
        System.out.println("normal bilet sayısı:");
        int norbilet = scan.nextInt();
        if (norbilet < 0) {
            System.out.println("hatalı veri girişi.");
            return;
        }

        if (kisi != norbilet + indBilet) {
            System.out.println("eksik giriş.");
            return;
        }
        double ucretSinema = (norbilet * 20.0) + (indBilet * 15.0);

        System.out.println("seans:\n" +
                "1- 10.00\n" +
                "2- 12.00\n" +
                "3- 14.00\n" +
                "4- 16.00\n" +
                "5- 18.00");
        System.out.println("seans seçimi yapınız:");
        int seans = scan.nextInt();


        KoltukSec koltukSec = new KoltukSec();

        switch (seans) {

            case 1:
                koltukSec.koltukgir10(arrayList10, kisi);
                break;
            case 2:
                koltukSec.koltukgir12(arrayList12, kisi);

                break;
            case 3:
                koltukSec.koltukgir14(arrayList14, kisi);
                break;
            case 4:
                koltukSec.koltukgir16(arrayList16, kisi);
                break;
            case 5:
                koltukSec.koltukgir18(arrayList18, kisi);
                break;
        }

        System.out.println("toplam tutar:" + ucretSinema + "TL");
        System.out.println("Bilet alma işlemine devam ediliyor." +
                "lütfen sorulan bilgileri eksiksiz tamamlayınız.");
        System.out.println("--------------------");
        kisiİnfo();

    }

}

