package bilet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        ArrayList<String> arrayList10 = new ArrayList<String>();
        arrayList10.add("1");
        arrayList10.add("2");
        arrayList10.add("3");
        arrayList10.add("4");
        arrayList10.add("5");
        arrayList10.add("6");
        arrayList10.add("7");
        arrayList10.add("8");
        arrayList10.add("9");
        arrayList10.add("10");

        ArrayList<String> arrayList12 = new ArrayList<String>();
        arrayList12.add("1");
        arrayList12.add("2");
        arrayList12.add("3");
        arrayList12.add("4");
        arrayList12.add("5");
        arrayList12.add("6");
        arrayList12.add("7");
        arrayList12.add("8");
        arrayList12.add("9");
        arrayList12.add("10");

        ArrayList<String> arrayList14 = new ArrayList<String>();
        arrayList14.add("1");
        arrayList14.add("2");
        arrayList14.add("3");
        arrayList14.add("4");
        arrayList14.add("5");
        arrayList14.add("6");
        arrayList14.add("7");
        arrayList14.add("8");
        arrayList14.add("9");
        arrayList14.add("10");

        ArrayList<String> arrayList16 = new ArrayList<String>();
        arrayList16.add("1");
        arrayList16.add("2");
        arrayList16.add("3");
        arrayList16.add("4");
        arrayList16.add("5");
        arrayList16.add("6");
        arrayList16.add("7");
        arrayList16.add("8");
        arrayList16.add("9");
        arrayList16.add("10");

        ArrayList<String> arrayList18 = new ArrayList<String>();
        arrayList18.add("1");
        arrayList18.add("2");
        arrayList18.add("3");
        arrayList18.add("4");
        arrayList18.add("5");
        arrayList18.add("6");
        arrayList18.add("7");
        arrayList18.add("8");
        arrayList18.add("9");
        arrayList18.add("10");


        while (true) {
            System.out.println("------------------------");
        System.out.println("Bilet sistemine hoşgeldiniz.");
        System.out.println("Gerçekleştirilmek istenen işlemi giriniz.\n" +
                "[1]- Sinema bileti satışı.\n" +
                "[2]- Tiyatro bileti satışı. \n" +
                "[3]- Konser bileti satışı.");
            //Bilet sisteminde giriş yapmak için karşılama cümleleri.
        Scanner scan = new Scanner(System.in);
        System.out.println("seçiminiz:");
        int karar = scan.nextInt();
            switch (karar) { //kullanıcıdan istenen işlem seçimi yapılır.
                case 1:
                    System.out.println("Sinema bileti satışı gerçekleştirilmektedir.");
                    try {
                        //Dosyalama işlemi ile kullanıcının girmiş olduğu film listesi çekilir.

                        File dosya = new File("film.txt");
                        dosya.createNewFile();
                        Scanner myReader = new Scanner(dosya);
                        while (myReader.hasNextLine()) {
                            String bilgi = myReader.nextLine();
                            System.out.println(bilgi);

                        }
                        ArrayList<String> data = new ArrayList<String>();
                        String[] dizi = data.toArray(new String[]{}); //dosyadan yazdırma işlemi.
                        System.out.println("film seçiniz:");
                        String fkarar = scan.next();
                        System.out.println("seçilen film:");
                        System.out.println(fkarar +".Salon");
                        sinema a = new sinema();
                        a.biletAl(arrayList10,arrayList12, arrayList14, arrayList16, arrayList18);
                        myReader.close();


                        try {
                            sinema mus = new sinema();
                            System.out.println("isim:");
                            String isim = scan.next();
                            System.out.println("soyisim:");
                            String soyisim = scan.next();
                            System.out.println("Telefon Numarası:");
                            String numara = scan.next();
                            MusBilgi c = new MusBilgi(isim,soyisim,numara);
                            FileWriter myWriter = new FileWriter("Sinemafiş.txt",true);
                            myWriter.write("-----------------\n" + c.isim  +" "+ c.soyisim +" "+ c.numara); //Çıktı olarak müşteriye fiş yazdırma.
                            myWriter.close();
                            System.out.println("Başarıyla yazıldı.");
                        } catch (IOException e) {
                            System.out.println("Hata.");
                            e.printStackTrace();
                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("dosya bulunamadı."); // hata komutu.
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    continue;

                case 2:
                    System.out.println("Tiyatro bileti satışı gerçekleştirilmektedir.");
                    try {

                        File dosya = new File("tiyatro.txt"); //tiyatro dosyası oluşturulur.
                        dosya.createNewFile();
                        Scanner myReader = new Scanner(dosya);
                        while (myReader.hasNextLine()) {
                            String bilgi = myReader.nextLine();
                            System.out.println(bilgi);

                        }
                        ArrayList<String> data = new ArrayList<String>();
                        String[] dizi = data.toArray(new String[]{}); //dosyadan girişler çekilir.
                        System.out.println("Oyun seçiniz:");
                        int fkarar = scan.nextInt();
                        System.out.println("seçilen oyun:");
                        System.out.println(fkarar +". salon");
                        tiyatro a = new tiyatro();
                        a.biletAl(arrayList10,arrayList12, arrayList14, arrayList16, arrayList18);
                        myReader.close();

                        try {
                            tiyatro mus = new tiyatro();
                            System.out.println("isim:");
                            String isim = scan.next();
                            System.out.println("soyisim:");
                            String soyisim = scan.next();
                            System.out.println("Telefon numarası:");
                            String numara = scan.next();
                            MusBilgi c = new MusBilgi(isim,soyisim,numara);
                            FileWriter myWriter = new FileWriter("TiyatroFiş.txt",true);
                            myWriter.write("-----------------\n" + c.isim  +" "+ c.soyisim +" "+ c.numara);
                             //Müşteri bilgileri dosyaya yazdırılır.
                            myWriter.close();
                            System.out.println("Başarıyla yazıldı.");
                        } catch (IOException e) {
                            System.out.println("Hata.");
                            e.printStackTrace();
                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("dosya bulunamadı.");
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;

                case 3:
                    System.out.println("Konser bileti satışı gerçekleştirilmektedir.");
                    try {

                        File dosya = new File("konser.txt"); //konser dosyası oluşturma.
                        dosya.createNewFile();
                        Scanner myReader = new Scanner(dosya);
                        while (myReader.hasNextLine()) {
                            String bilgi = myReader.nextLine();
                            System.out.println(bilgi);

                        }
                        ArrayList<String> data = new ArrayList<String>();
                        String[] dizi = data.toArray(new String[]{}); //dosyadan konser listesi çekme işlemi.
                        System.out.println("Konser seçiniz:");
                        int fkarar = scan.nextInt();
                        System.out.println("seçilen Konser:");
                        System.out.println(fkarar + ". salon");
                        konser a = new konser();
                        a.biletAl();
                        myReader.close();

                        try {
                            //tiyatro mus = new tiyatro();
                            //String yazilacak = mus.kisiİnfo();
                            System.out.println("isim:");
                            String isim = scan.next();
                            System.out.println("soyisim:");
                            String soyisim = scan.next();
                            System.out.println("Telefon numarası:");
                            String numara = scan.next();
                            MusBilgi c = new MusBilgi(isim,soyisim,numara);
                            FileWriter myWriter = new FileWriter("KonserFiş.txt",true);
                            myWriter.write("-----------------\n" + c.isim  +" "+ c.soyisim +" "+ c.numara);
                            //müşteri bilgilerini dosyaya yazdırma.
                            myWriter.close();
                            System.out.println("Başarıyla yazıldı.");
                        } catch (IOException e) {
                            System.out.println("Hata.");
                            e.printStackTrace();
                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("dosya bulunamadı.");
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                default:
                    System.out.println("Yapılan tercih geçersizdir."); // seçilmesi gerekenler dışında işlem yapılırsa.
                    break;


            }

        }
    }
}
