package bilet;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KoltukSec {
    Scanner scan = new Scanner(System.in);

    public void koltukgir10(ArrayList<String> arrayList10, int kisi){
        System.out.println("10.00 seansı seçildi.");
        System.out.println("koltuk seçimi:");

        for(int i=1; i<=kisi; i++){
            System.out.println(arrayList10);
            String koltuk = scan.next();
            int sayiKoltuk = Integer.parseInt(koltuk);
            arrayList10.set(sayiKoltuk-1, "Dolu");

        }
        System.out.println(" kalan koltuk numaraları:" + arrayList10);

    }


    public void koltukgir12(ArrayList<String> arrayList12, int kisi){
        System.out.println("12.00 seansı seçildi.");
        System.out.println("koltuk seçimi:");

        for(int i=1; i<=kisi; i++){
            System.out.println(arrayList12);
            String koltuk = scan.next();
            int sayiKoltuk = Integer.parseInt(koltuk);
            arrayList12.set(sayiKoltuk-1, "Dolu");

        }
        System.out.println(" kalan koltuk numaraları:" + arrayList12);

    }
    public void koltukgir14(ArrayList<String> arrayList14, int kisi){
        System.out.println("14.00 seansı seçildi.");
        System.out.println("koltuk seçimi:");

        for(int i=1; i<=kisi; i++){
            System.out.println(arrayList14);
            String koltuk = scan.next();
            int sayiKoltuk = Integer.parseInt(koltuk);
            arrayList14.set(sayiKoltuk-1, "Dolu");

        }
        System.out.println(" kalan koltuk numaraları:" + arrayList14);

    }
    public void koltukgir16(ArrayList<String> arrayList16, int kisi){
        System.out.println("16.00 seansı seçildi.");
        System.out.println("koltuk seçimi:");

        for(int i=1; i<=kisi; i++){
            System.out.println(arrayList16);
            String koltuk = scan.next();
            int sayiKoltuk = Integer.parseInt(koltuk);
            arrayList16.set(sayiKoltuk-1, "Dolu");

        }
        System.out.println(" kalan koltuk numaraları:" + arrayList16);

    }
    public void koltukgir18(ArrayList<String> arrayList18, int kisi){
        System.out.println("18.00 seansı seçildi.");
        System.out.println("koltuk seçimi:");

        for(int i=1; i<=kisi; i++){
            System.out.println(arrayList18);
            String koltuk = scan.next();
            int sayiKoltuk = Integer.parseInt(koltuk);
            arrayList18.set(sayiKoltuk-1, "Dolu");

        }
        System.out.println(" kalan koltuk numaraları:" + arrayList18);

    }

}
