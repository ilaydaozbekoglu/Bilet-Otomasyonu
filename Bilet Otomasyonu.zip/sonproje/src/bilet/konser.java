package bilet;

import java.util.Scanner;

public class konser implements islemler{
    Scanner scan = new Scanner(System.in);
    @Override
    public void biletAl() {
    biletSat();
    }

    @Override
    public void kisiİnfo() {


    }

    public void biletSat(){
        System.out.println("kişi sayısı:");
        int kisi = scan.nextInt();
        if(kisi <=0){
            System.out.println("geçersiz bir kişi sayısı girildi. Lütfen yeniden deneyiniz.");
            return;
        }
        System.out.println("Normal bilet sayısı:");
        int NBilet = scan.nextInt();
        if (NBilet <0){
            System.out.println("hatalı veri girişi.");
            return;
        }
        System.out.println("VIP bilet sayısı:");
        int Vbilet= scan.nextInt();
        if(Vbilet <0){
            System.out.println("hatalı veri girişi.");
            return;
        }

        if(kisi != Vbilet + NBilet){
            System.out.println("eksik giriş.");
            return;
        }
        double ucretKonser = (Vbilet*100.0)+(NBilet*75.0);
        //Konser classı altında koltuk ve seans seçimi yapılmaz.
        //konserler ayakta ve belli saatler verilerek düşünülmüştür.


        System.out.println("toplam tutar:" + ucretKonser + "TL");
        System.out.println("Bilet alma işlemine devam ediliyor." +
                "lütfen sorulan bilgileri eksiksiz tamamlayınız.");
        System.out.println("--------------------");
        kisiİnfo();

    }





}
